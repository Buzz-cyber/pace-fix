import Contact from "../../src/assets/pages/contact"

export default function ContactPage() {
  return <Contact />
}

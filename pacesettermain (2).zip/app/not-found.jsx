import ErrorPage from "../src/assets/pages/error"

export default function NotFound() {
  return <ErrorPage />
}

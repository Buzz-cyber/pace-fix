import About from "../../src/assets/pages/about"

export default function AboutPage() {
  return <About />
}

import RemoveLater from "../../src/assets/pages/RemoveLater"

export default function TestPage() {
  return <RemoveLater />
}

// import Search from "../../assets/pages/search"

export default function DateSearchPage() {
  return <div>Search</div>
  // return <Search />
}

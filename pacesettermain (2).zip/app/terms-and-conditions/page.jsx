import Terms from "../../src/assets/pages/terms"

export default function TermsPage() {
  return <Terms />
}

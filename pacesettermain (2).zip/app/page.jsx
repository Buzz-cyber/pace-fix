import Welcome from "../src/assets/pages/welcome"

export default function HomePage() {
  return <Welcome />
}

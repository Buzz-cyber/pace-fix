import Privacy from "../../src/assets/pages/privacy"

export default function PrivacyPage() {
  return <Privacy />
}

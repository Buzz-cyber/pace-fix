import PostPage from "../../../../src/assets/pages/post"

export default function PostDetailPage() {
  return <PostPage />
}

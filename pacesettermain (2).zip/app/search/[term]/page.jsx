import Search from "../../../src/assets/pages/search"

export default function SearchPage() {
  return <Search />
}

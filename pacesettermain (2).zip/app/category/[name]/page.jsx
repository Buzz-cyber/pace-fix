import Category from "../../../src/assets/pages/category"

export default function CategoryPage() {
  return <Category />
}

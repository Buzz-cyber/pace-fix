"use client"

import { Common } from "../../components"

const BusinessEconomy = () => {
  return (
    <>
      <Common name="Business/Economy" start={0} />
    </>
  )
}

export default BusinessEconomy

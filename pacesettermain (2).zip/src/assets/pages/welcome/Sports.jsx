"use client"

import { Common } from "../../components"

const Sports = () => {
  return (
    <>
      <Common name="Sports" start={0} />
    </>
  )
}

export default Sports

"use client"

import { Common } from "../../components"

const Novella = () => {
  return <Common name="Novella" start={0} />
}

export default Novella

"use client"

import { Common } from "../../components"

const News = () => {
  return <Common name="News" start={0} />
}

export default News

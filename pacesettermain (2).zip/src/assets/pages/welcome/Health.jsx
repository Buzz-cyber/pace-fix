"use client"

import { Common } from "../../components"

const Health = () => {
  return (
    <>
      <Common name="Health" start={0} />
    </>
  )
}

export default Health

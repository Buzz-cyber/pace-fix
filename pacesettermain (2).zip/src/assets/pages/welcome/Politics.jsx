"use client"

import { Common } from "../../components"

const Politics = () => {
  return (
    <>
      <Common name="Politics" start={0} />
    </>
  )
}

export default Politics

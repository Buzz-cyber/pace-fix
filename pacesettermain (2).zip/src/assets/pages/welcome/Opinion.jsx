"use client"

import { Common } from "../../components"

const Opinion = () => {
  return (
    <>
      <Common name="Opinion" start={0} />
    </>
  )
}

export default Opinion

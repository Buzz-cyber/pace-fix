"use client"

import { Common } from "../../components"

const Fashion = () => {
  return <Common name="Fashion" start={0} />
}

export default Fashion

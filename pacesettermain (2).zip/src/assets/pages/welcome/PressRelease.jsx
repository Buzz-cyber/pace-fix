"use client"

import { Common } from "../../components"

const PressRelease = () => {
  return (
    <>
      <Common name="Press Release" start={0} />
    </>
  )
}

export default PressRelease

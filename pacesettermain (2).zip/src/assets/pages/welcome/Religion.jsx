"use client"

import { Common } from "../../components"

const Religion = () => {
  return (
    <>
      <Common name="Religion" start={0} />
    </>
  )
}

export default Religion

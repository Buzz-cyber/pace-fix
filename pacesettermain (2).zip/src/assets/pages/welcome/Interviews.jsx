"use client"

import { Common } from "../../components"

const Interviews = () => {
  return (
    <>
      <Common name="Interviews" start={0} />
    </>
  )
}

export default Interviews

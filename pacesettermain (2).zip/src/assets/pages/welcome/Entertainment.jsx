"use client"

import { Common } from "../../components"

const Entertainment = () => {
  return (
    <>
      <Common name="Entertainment" start={0} />
    </>
  )
}

export default Entertainment

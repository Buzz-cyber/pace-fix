"use client"

import { Common } from "../../components"

const Education = () => {
  return (
    <>
      <Common name="Education" start={0} />
    </>
  )
}

export default Education

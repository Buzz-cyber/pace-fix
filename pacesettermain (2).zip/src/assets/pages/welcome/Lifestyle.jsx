"use client"

import { Common } from "../../components"

const Lifestyle = () => {
  return (
    <>
      <Common name="Lifestyle" start={0} />
    </>
  )
}

export default Lifestyle

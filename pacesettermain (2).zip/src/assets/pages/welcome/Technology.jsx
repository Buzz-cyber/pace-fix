"use client"

import { Common } from "../../components"

const Technology = () => {
  return (
    <>
      <Common name="Technology" start={0} />
    </>
  )
}

export default Technology

import Adverts from "./Adverts";
import { Common, SideMain } from "./Article";
import { CommentDetails} from "./Comments";
import Footer from "./Footer";

export { Adverts, CommentDetails, Common, Footer, SideMain };

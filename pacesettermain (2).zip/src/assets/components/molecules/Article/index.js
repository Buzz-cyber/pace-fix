import CommonHome from "./CommonHome";
import SideMain from "./SideMain";

export {CommonHome as Common, SideMain};

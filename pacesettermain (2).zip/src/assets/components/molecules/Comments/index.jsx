import Details from "./Details";

export {Details as CommentDetails}

import NavBar from "./NavBar";
import Top from "./Top";

import "./style.css";

const Index = () => (
  <>
    <Top />
    <NavBar />
  </>
);
export default Index;

import TopHero from "./TopHero";
import {VerticalSegment, TextFirstSegment, LittlePieceSegment} from "./Segment";

export { TopHero, VerticalSegment, TextFirstSegment, LittlePieceSegment};

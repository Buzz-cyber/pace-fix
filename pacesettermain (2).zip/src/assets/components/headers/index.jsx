import ArticleTitle from "./ArticleTitle";
import PostTitle from "./PostTitle";

export { ArticleTitle, PostTitle };

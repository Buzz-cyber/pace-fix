import "./style.css"
import Latest, {SideBar, BottomRecent} from "./Latest";

export { Latest, SideBar as SideBarRecentSlider, BottomRecent };

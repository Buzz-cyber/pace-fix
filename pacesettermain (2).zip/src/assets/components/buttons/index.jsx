import LoadMore from "./LoadMore";
import Pills from "./Pills";

export { LoadMore, Pills as SocialPills };
